--date: May 18, 2016
--useful vCenter parameter to look at overall.

col name format a45;
col value format a100;
select * from vpx_parameter;